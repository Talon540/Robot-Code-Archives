
package org.usfirst.frc.team540.robot;

import edu.wpi.first.wpilibj.AnalogGyro;
import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SD540;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.networktables.NetworkTable;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {
    final String defaultAuto = "Do Nothing";
    final String Auto1 = "1", Auto2 = "2", Auto3 = "3", Auto4 = "4", Auto5 = "5", Auto6 = "6", Auto7 = "7", Auto8 = "8", Auto9 = "9";
    String autoSelected;
    SendableChooser chooser;
	
    double VI = 0.009765625; //voltage provided to ultra (5) divided by its range (512)
    
    AnalogInput ultra;
    double distance;
    AnalogGyro gyro;
    AnalogInput IR;
    int time;
    int count;
    boolean counted;
    
    Victor rightDrive1, rightDrive2;
	SD540 intake, loader,shooter1, shooter2, climber1, climber2, leftDrive1, leftDrive2;
	Joystick leftStick, rightStick;
	XboxController xbox;
	double yLeft, yRight, shoot, load, shootSpeed;
	boolean intakeForward, intakeReverse, climb, shoot_align, auto = true;
	int counter = 0;
	
	NetworkTable table;
	public static double[] tableVals = {0,0};
    
    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
    public void robotInit() {
        chooser = new SendableChooser();
        chooser.addDefault("Default Auto", defaultAuto);
        chooser.addObject("Auto1", Auto1);
        chooser.addObject("Auto2", Auto2);
        chooser.addObject("Auto3", Auto3);
        chooser.addObject("Auto4", Auto4);
        chooser.addObject("Auto5", Auto5);
        chooser.addObject("Auto6", Auto6);
        chooser.addObject("Auto7", Auto7);
        chooser.addObject("Auto8", Auto8);
        SmartDashboard.putData("Auto choices", chooser);
        
        ultra = new AnalogInput(2);
        gyro = new AnalogGyro(0);
        IR = new AnalogInput(1);
        
        rightDrive1 = new Victor(0);
		rightDrive2 = new Victor(1);
	    leftDrive1 = new SD540(2);
	    leftDrive2 = new SD540(3);
	    //intake = new Victor(4);
	    //loader = new Victor(5);
	    //shooter1 = new Victor(6);
	    //shooter2 = new Victor(7);
	    climber1 = new SD540(4);
	    climber2 = new SD540(5); 
	    leftStick = new Joystick(0);
	    rightStick = new Joystick(1);
	    xbox = new XboxController(2);
	    
	    table = NetworkTable.getTable("peg");
	    NetworkTable.setServerMode();
    }
    
	/**
	 * This autonomous (along with the chooser code above) shows how to select between different autonomous modes
	 * using the dashboard. The sendable chooser code works with the Java SmartDashboard. If you prefer the LabVIEW
	 * Dashboard, remove all of the chooser code and uncomment the getString line to get the auto name from the text box
	 * below the Gyro
	 *
	 * You can add additional auto modes by adding additional comparisons to the switch structure below with additional strings.
	 * If using the SendableChooser make sure to add them to the chooser code above as well.
	 */
    public void autonomousInit() {
    	autoSelected = (String) chooser.getSelected();
		autoSelected = SmartDashboard.getString("Auto Selector", defaultAuto);
		//System.out.println("Auto selected: " + autoSelected);
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
    	distance = ultra.getVoltage()/VI;
    	tableVals[0] = table.getNumber("area", 0);
    	tableVals[1] = table.getNumber("align", 0);
    	double cameraArea = tableVals[0];
    	double align = tableVals[1];
    	
    	switch(autoSelected) {
    	
    	case Auto9: // Scorched earth, empty hoppers; Blue Alliance (2 hoppers right, 1 hopper right)
    		if(auto) {
    			
    		}
    		auto = false;
    	
    	case Auto8: // Scorched earth. empty hoppers; Red Alliance (2 hoppers left, 1 hopper right)
    		if(auto) {
    			
    		}
    		auto = false;
    	
    	case Auto7: // Blue Alliance, Boiler side; left peg, shoot into boiler, go to midfield
    		if(auto) {
    			if(auto) {
        			if(counter == 0) { // move forward
        				leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
        				Timer.delay(1); // TODO change according to speed
        				
        				gyro.reset();
        				counter++;
        			}
        			else if(counter == 1) { // turn right towards the peg
        				if(gyro.getAngle() > 45) {
        					leftDrive1.set(-0.5);
        					leftDrive2.set(-0.5);
        					rightDrive1.set(-0.5);
        					rightDrive2.set(-0.5);
        				}
        				else counter++;
        			}
        			else if(counter == 2) { // approach peg and wait there for a bit to allow the gear to be lifted
        				if(distance < 10) { // TODO set distance
        					leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
        				}
        				else {
        					leftDrive1.set(0);
            				leftDrive2.set(0);
            				rightDrive1.set(0);
            				rightDrive2.set(0);
            				
            				Timer.delay(2);
            				counter++;
        				}
        			}
        			else if(counter == 3) { // go in reverse
        				leftDrive1.set(0.5);
        				leftDrive2.set(0.5);
        				rightDrive1.set(-0.5);
        				rightDrive2.set(-0.5);
        				Timer.delay(0.5);
        				
        				gyro.reset();
        				counter++;
        			}
        			else if (counter == 4) { // turn left towards goal (EDIT THIS)
        				if (gyro.getAngle() < -10) {
        					leftDrive1.set(0.5);
            				leftDrive2.set(0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				counter++;
        				}
        			}
        			else if (counter == 5)
        			{
        				if (align == -1) //Turns right if misaligned to the left
        				{
        					leftDrive1.set(-0.5);
        					leftDrive2.set(-0.5);
        					rightDrive1.set(-0.5);
        					rightDrive2.set(-0.5);
        				}
        				else if (align == 1) //Turns left if misaligned to the right
        				{
        					leftDrive1.set(0.5);
        					leftDrive2.set(0.5);
        					rightDrive1.set(0.5);
        					rightDrive2.set(0.5);
        				}
        				else //Aligned
        				{
        					leftDrive1.set(0);
        					leftDrive2.set(0);
        					rightDrive1.set(0);
        					rightDrive2.set(0);
        					counter++;
        				}
        			}
        			else if (counter == 6)
        			{
    					if (cameraArea > 3000)
    					{
    						shooter1.set(1);
    						shooter2.set(1);
    					}
    					else if (cameraArea > 2000)
    					{
    						shooter1.set(0.75);
    						shooter2.set(0.75);
    					}
    					else if (cameraArea > 1500)
    					{
    						shooter1.set(0.5);
    						shooter2.set(0.5);
    					}
    					else if (cameraArea > 1000)
    					{
    						shooter1.set(0.25);
    						shooter2.set(0.25);
    					}
    					else
    					{
    						shooter1.set(0.5);
    						shooter2.set(0.5);
    					}
        			}
        			/* CONFIRM SHOOTING WORKS BEFORE UNCOMMENTING THIS
    				else { // drive into midfield
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
        				Timer.delay(2);
        				
        				leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				counter++;
    				}*/
        		}
    		}
    		auto = false;
    	
    	case Auto6: // Red Alliance, Boiler side; right peg, shoot into boiler, go to midfield
    		if(auto) {
    			if(counter == 0) { // move forward
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1); // TODO change according to speed
    				
    				gyro.reset();
    				counter++;
    			}
    			else if(counter == 1) { // turn left towards the peg
    				if(gyro.getAngle() > -45) {
    					leftDrive1.set(0.5);
    					leftDrive2.set(0.5);
    					rightDrive1.set(0.5);
    					rightDrive2.set(0.5);
    				}
    				else counter++;
    			}
    			else if(counter == 2) { // approach peg and wait there for a bit to allow the gear to be lifted
    				if(distance < 10) { // TODO set distance
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
    				}
    				else {
    					leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				
        				Timer.delay(2);
        				counter++;
    				}
    			}
    			else if(counter == 3) { // go in reverse
    				leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);
    				
    				gyro.reset();
    				counter++;
    			}
    			else if (counter == 4) { // turn right towards goal (EDIT THIS)
    				if (gyro.getAngle() < -10) {
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(-0.5);
        				rightDrive2.set(-0.5);
        				counter++;
    				}
    			}
    			else if (counter == 5)
    			{
    				if (align == -1) //Turns right if misaligned to the left
    				{
    					leftDrive1.set(-0.5);
    					leftDrive2.set(-0.5);
    					rightDrive1.set(-0.5);
    					rightDrive2.set(-0.5);
    				}
    				else if (align == 1) //Turns left if misaligned to the right
    				{
    					leftDrive1.set(0.5);
    					leftDrive2.set(0.5);
    					rightDrive1.set(0.5);
    					rightDrive2.set(0.5);
    				}
    				else //Aligned
    				{
    					leftDrive1.set(0);
    					leftDrive2.set(0);
    					rightDrive1.set(0);
    					rightDrive2.set(0);
    					counter++;
    				}
    			}
    			else if (counter == 6)
    			{
    				if (cameraArea > 3000)
					{
						shooter1.set(1);
						shooter2.set(1);
					}
					else if (cameraArea > 2000)
					{
						shooter1.set(0.75);
						shooter2.set(0.75);
					}
					else if (cameraArea > 1500)
					{
						shooter1.set(0.5);
						shooter2.set(0.5);
					}
					else if (cameraArea > 1000)
					{
						shooter1.set(0.25);
						shooter2.set(0.25);
					}
					else
					{
						shooter1.set(0.5);
						shooter2.set(0.5);
					}
    			}
    			/* 
    			 * TODO CONFIRM SHOOTING WORKS BEFORE UNCOMMENTING THIS
				else { // drive into midfield
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(2);
    				
    				leftDrive1.set(0);
    				leftDrive2.set(0);
    				rightDrive1.set(0);
    				rightDrive2.set(0);
    				counter++;
				}*/
    		}
    		auto = false;
    	
    	case Auto5: // Red Alliance, Loading Station side; left peg, cross baseline, go to midfield
    		if(auto) {
    			if(counter == 0) { // move forward
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1); // TODO change according to speed
    				
    				gyro.reset();
    				counter++;
    			}
    			else if(counter == 1) { // turn right towards the peg
    				if(gyro.getAngle() < 45) {
    					leftDrive1.set(-0.5);
    					leftDrive2.set(-0.5);
    					rightDrive1.set(-0.5);
    					rightDrive2.set(-0.5);
    				}
    				else counter++;
    			}
    			else if(counter == 2) { // approach peg and wait there for a bit to allow the gear to be lifted
    				if(distance < 10) { // TODO set distance
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
    				}
    				else {
    					leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				
        				Timer.delay(2);
        				counter++;
    				}
    			}
    			else if(counter == 3) { // go in reverse
    				leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);
    				
    				gyro.reset();
    				counter++;
    			}
    			else if (counter == 4) { // turn left
    				if (gyro.getAngle() > -45) {
    					leftDrive1.set(0.5);
        				leftDrive2.set(0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
    				}
    				else { // drive into midfield
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
        				Timer.delay(2);
        				
        				leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				counter++;
    				}
    			}
    		}
    		auto = false;
    	
    	case Auto4: // Blue Alliance, Loading Station side; right peg, cross baseline, go to midfield
    		if(auto) {
    			if(counter == 0) { // move forward
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1); // TODO change according to speed
    				
    				gyro.reset();
    				counter++;
    			}
    			else if(counter == 1) { // turn left towards the peg
    				if(gyro.getAngle() > -45) {
    					leftDrive1.set(0.5);
    					leftDrive2.set(0.5);
    					rightDrive1.set(0.5);
    					rightDrive2.set(0.5);
    				}
    				else counter++;
    			}
    			else if(counter == 2) { // approach peg and wait there for a bit to allow the gear to be lifted
    				if(distance < 10) { // TODO set distance
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
    				}
    				else {
    					leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				
        				Timer.delay(2);
        				counter++;
    				}
    			}
    			else if(counter == 3) { // go in reverse
    				leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);
    				
    				gyro.reset();
    				counter++;
    			}
    			else if (counter == 4) { // turn right
    				if (gyro.getAngle() < 45) {
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(-0.5);
        				rightDrive2.set(-0.5);
    				}
    				else { // drive into midfield
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
        				Timer.delay(2);
        				
        				leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				counter++;
    				}
    			}
    		}
    		auto = false;
    	
    	case Auto3: // Go for center peg then go to the midfield via right path
    		if(auto) {
    			if(counter == 0) { // Drive forward
	    			if (distance > 10) { // TODO set distance
	    				leftDrive1.set(-0.5);
	    				leftDrive2.set(-0.5);
	    				rightDrive1.set(0.5);
	    				rightDrive2.set(0.5);
	    			}
	    			else counter++;
	    		}
	    		else if(counter == 1) { // Stay still to get the gear lifted
	    			leftDrive1.set(0);
	        		leftDrive2.set(0);
	        		rightDrive1.set(0);
	        		rightDrive2.set(0);
	        		Timer.delay(2);
	        		
	        		leftDrive1.set(0.5); // Back up
	        		leftDrive2.set(0.5);
	        		rightDrive1.set(-0.5);
	        		rightDrive2.set(-0.5);
	        		Timer.delay(0.5); // TODO change this according to speed
	        		
	        		gyro.reset();
	        		counter++;
	    		}
	    		else if(counter == 2) { // Turn right
	        		if(gyro.getAngle() > 90) {
		        		leftDrive1.set(-0.5);
		        		leftDrive2.set(-0.5);
		        		rightDrive1.set(-0.5);
		        		rightDrive2.set(-0.5);
	        		}
	        		else counter++;
	    		}
	    		else if(counter == 3) { // Drive forward
	    			leftDrive1.set(-0.5);
	    			leftDrive2.set(-0.5);
	    			rightDrive1.set(0.5);
	    			rightDrive2.set(0.5);
	    			Timer.delay(1);
	    			
	    			gyro.reset();
	    			counter++;
	    		}
	    		else if(counter == 4) { // Turn left
	    			if(gyro.getAngle() < 90) {
	    				leftDrive1.set(0.5);
	    				leftDrive2.set(0.5);
	    				rightDrive1.set(0.5);
	    				rightDrive2.set(0.5);
	    			}
	    			else counter++;
	    		}
	    		else { // Drive forward
	    			leftDrive1.set(-0.5);
	    			leftDrive2.set(-0.5);
	    			rightDrive1.set(0.5);
	    			rightDrive2.set(0.5);
	    			Timer.delay(2);
	    		}
    		}
    		auto = false;
    	
    	case Auto2: // Go for center peg then go to the midfield via left path
    		if(auto) {
	    		if(counter == 0) { // Drive forward
	    			if (distance > 10) { // TODO set distance
	    				leftDrive1.set(-0.5);
	    				leftDrive2.set(-0.5);
	    				rightDrive1.set(0.5);
	    				rightDrive2.set(0.5);
	    			}
	    			else counter++;
	    			
	    		}
	    		else if(counter == 1) { // Stay still to get the gear lifted
	    			leftDrive1.set(0);
	        		leftDrive2.set(0);
	        		rightDrive1.set(0);
	        		rightDrive2.set(0);
	        		Timer.delay(2);
	        		
	        		leftDrive1.set(0.5); // Back up
	        		leftDrive2.set(0.5);
	        		rightDrive1.set(-0.5);
	        		rightDrive2.set(-0.5);
	        		Timer.delay(0.5); // TODO change this according to speed
	        		
	        		gyro.reset();
	        		counter++;
	    		}
	    		else if(counter == 2) { // Turn left
	        		if(gyro.getAngle() > -90) {
		        		leftDrive1.set(0.5);
		        		leftDrive2.set(0.5);
		        		rightDrive1.set(0.5);
		        		rightDrive2.set(0.5);
	        		}
	        		else
	        			counter++;
	    		}
	    		else if(counter == 3) { // Drive forward
	    			leftDrive1.set(-0.5);
	    			leftDrive2.set(-0.5);
	    			rightDrive1.set(0.5);
	    			rightDrive2.set(0.5);
	    			Timer.delay(1);
	    			
	    			gyro.reset();
	    			counter++;
	    		}
	    		else if(counter == 4) { // Turn right
	    			if(gyro.getAngle() < 90) {
	    				leftDrive1.set(-0.5);
	    				leftDrive2.set(-0.5);
	    				rightDrive1.set(-0.5);
	    				rightDrive2.set(-0.5);
	    			}
	    			else
	    				counter++;
	    		}
	    		else { // Drive forward
	    			leftDrive1.set(-0.5);
	    			leftDrive2.set(-0.5);
	    			rightDrive1.set(0.5);
	    			rightDrive2.set(0.5);
	    			Timer.delay(2);
	    		}
    		}
    		auto = false;
    		
    	case Auto1: // Cross baseline
    		if(auto) {
	    		leftDrive1.set(-0.5);
	    		leftDrive2.set(-0.5);
	    		rightDrive1.set(0.5);
	    		rightDrive2.set(0.5);
	    		Timer.delay(2);
    		}
    		auto = false;
    	
    	case defaultAuto: // Do nothing
    		leftDrive1.set(0);
    		leftDrive2.set(0);
    		rightDrive1.set(0);
    		rightDrive2.set(0);
    		intake.set(0);
    		loader.set(0);
    		shooter1.set(0);
    		shooter2.set(0);
    		climber1.set(0);
    		climber2.set(0);
    	default:
    	//Put default auto code here
            break;
    	}
    }

    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
        distance = ultra.getVoltage()/VI; //converts voltage to distance in inches
        tableVals[0] = table.getNumber("area", 0);
        tableVals[1] = table.getNumber("align", 0);
        double cameraArea = tableVals[0];
        double align = tableVals[1];
        SmartDashboard.putNumber("Distance (in):", distance);
        SmartDashboard.putNumber("Angle: ", gyro.getAngle());
        SmartDashboard.putNumber("area", cameraArea);
        SmartDashboard.putNumber("align", align);
        
        if (IR.getVoltage() > 0.7) {
        	intake.set(1);
        	time++;
        	counted = true;
        	if (counted) count++;
        } else if (time >= 50) { //if ball stays in magnet for more than 2 seconds it unjams
        	intake.set(-1);
        } else {
        	intake.set(0);
        	time = 0;
        	counted = false;
        }
        
        if (rightStick.getRawButton(0)) {
        	gyro.reset();
        }
        
        yLeft = -leftStick.getY();
		yRight = rightStick.getY();
		intakeForward = xbox.getBButton();
		intakeReverse = xbox.getAButton();
		climb = xbox.getXButton();
		shoot_align = xbox.getYButton();
		shoot = xbox.getRawAxis(2);
		load = xbox.getRawAxis(3);		
		shootSpeed = 1;
		
		if(Math.abs(yLeft) <= 0.2) { //deadzones for left joystick
			leftDrive1.set(0);
			leftDrive2.set(0);
		}
		else { //movement for left joystick
			leftDrive1.set(yLeft);
			leftDrive2.set(yLeft);
		}
		if(Math.abs(yRight) <= 0.2) { //deadzones for right joystick
			rightDrive1.set(0);
			rightDrive2.set(0);
		}
		else { //movement for right joystick
			rightDrive1.set(yRight);
			rightDrive2.set(yRight);
		}
		
		if(intakeForward && intakeReverse) //If A and B are both pressed, nothing happens
			intake.set(0);
		else if(intakeForward) //A button to intake
			intake.set(1);
		else if(intakeReverse) //B button to spit out
			intake.set(-1);
		else //If neither button is pressed, do nothing
			intake.set(0);
		
		if(load <= 0.2) //loading deadzone
			loader.set(0);
		else //turn on loading motor
			loader.set(1);
		
		if (shoot_align)
		{
			if (align == -1) //Turns right if misaligned to the left
			{
				leftDrive1.set(-0.5);
				leftDrive2.set(-0.5);
				rightDrive1.set(-0.5);
				rightDrive2.set(-0.5);
			}
			else if (align == 1) //Turns left if misaligned to the right
			{
				leftDrive1.set(0.5);
				leftDrive2.set(0.5);
				rightDrive1.set(0.5);
				rightDrive2.set(0.5);
			}
			else //Aligned
			{
				leftDrive1.set(0);
				leftDrive2.set(0);
				rightDrive1.set(0);
				rightDrive2.set(0);
			}
		}
		
		if(shoot <= 0.2) { //shooting deadzone
			shooter1.set(0);
			shooter2.set(0);
		}
		else { //turn on shooting motors when trigger is pressed
			//Sets motor power based on distance from goal
			if (cameraArea > 3000)
			{
				shooter1.set(1);
				shooter2.set(1);
			}
			else if (cameraArea > 2000)
			{
				shooter1.set(0.75);
				shooter2.set(0.75);
			}
			else if (cameraArea > 1500)
			{
				shooter1.set(0.5);
				shooter2.set(0.5);
			}
			else if (cameraArea > 1000)
			{
				shooter1.set(0.25);
				shooter2.set(0.25);
			}
			else
			{
				shooter1.set(0.5);
				shooter2.set(0.5);
			}
			
			//shooter1.set(1);
			//shooter2.set(1);
		}
		
		if(climb) { //if X is pressed, climb
			climber1.set(1);
			climber2.set(1);
		}
		else { //else do nothing
			climber1.set(0);
			climber2.set(0);
		}

    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
    
    }
    
}
