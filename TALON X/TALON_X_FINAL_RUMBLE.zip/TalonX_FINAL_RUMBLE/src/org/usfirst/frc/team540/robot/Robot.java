package org.usfirst.frc.team540.robot;

import com.mindsensors.CANLight;
import com.mindsensors.CANSD540;
import com.mindsensors.CANSD540.StopMode;
import edu.wpi.first.wpilibj.AnalogGyro;
import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.GenericHID.RumbleType;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.PowerDistributionPanel;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.networktables.NetworkTable;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {
	public static double[] tableVals = {0,0};
    final String defaultAuto = "Default", Auto1 = "1", Auto2 = "2", Auto3 = "3", Auto4 = "4", Auto5 = "5", Auto6 = "6", Auto7 = "7", Auto8 = "8", Auto9 = "9";
    boolean intakeForward, intakeReverse, climb, shoot_align, funTime, coastBreakLeft, coastBreakRight, gyroForward, gyroBackward, left90, right90, one80, gyroLock, forty;
    double distance, yLeft, yRight, shoot, load, cameraArea, align;
    int timeIntake, canCount = 0, counter = 0, idk = 0, autoTest = 0;
    String autoSelected;
	SendableChooser chooser;    
    AnalogInput ultra, IR;
    AnalogGyro gyro; //Analog 0 and 1 are the only ports that this works in because SPI.
    CANSD540 leftDrive1, leftDrive2, rightDrive1, rightDrive2, intake, loader, shooter1, shooter2, climber1, climber2;
	Joystick leftStick, rightStick;
	XboxController xbox;	
	NetworkTable table;
	CANLight light;
    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
	
	public void robotInit(){
        chooser = new SendableChooser();
        chooser.addDefault("Do Nothing", defaultAuto);
        chooser.addObject("Cross Base Line", Auto1);
        chooser.addObject("Center Peg", Auto2);
        chooser.addObject("Center Gear; Cross Base Line; Left", Auto3);
        chooser.addObject("LS Gear; Cross Base Line; BlueAliance", Auto4);
        chooser.addObject("LS Gear; Cross Base Line; RedAliance", Auto5);
        chooser.addObject("Side Peg to the right", Auto6);
        chooser.addObject("Side Peg to the left", Auto7);
        chooser.addObject("Scorched Earth; BlueAlliance", Auto8);
        chooser.addObject("Scorched Eath; RedAlliance", Auto9); 
        SmartDashboard.putData("Auto choices", chooser);
        SmartDashboard.getNumber("autoTest", 0);
        gyro = new AnalogGyro(0);
        IR = new AnalogInput(1);
        ultra = new AnalogInput(2);
        loader = new CANSD540(1); //11
	    intake = new CANSD540(2); //12
	    climber1 = new CANSD540(3); //13
	    climber2 = new CANSD540(4); //14
	    shooter1 = new CANSD540(5); //15
	    shooter2 = new CANSD540(6); //16
	    rightDrive1 = new CANSD540(7); //17
	    rightDrive2 = new CANSD540(8); //18
        leftDrive1 = new CANSD540(9); //19
		leftDrive2 = new CANSD540(10); //20
	    light = new CANLight(11); //21
	    leftStick = new Joystick(0);
	    rightStick = new Joystick(1);
	    xbox = new XboxController(2);
	    table = NetworkTable.getTable("peg");
	    NetworkTable.setServerMode();
	    CameraServer.getInstance().addAxisCamera("10.5.40.15");
	    CameraServer.getInstance().startAutomaticCapture();
	    leftDrive1.setStopMode(StopMode.Brake);
	    leftDrive2.setStopMode(StopMode.Brake);
	    rightDrive1.setStopMode(StopMode.Brake);
	    rightDrive2.setStopMode(StopMode.Brake);
	    intake.setStopMode(StopMode.Brake);
	    loader.setStopMode(StopMode.Brake);
	    shooter1.setStopMode(StopMode.Brake);
	    shooter2.setStopMode(StopMode.Brake);
	    climber1.setStopMode(StopMode.Brake);
	    climber2.setStopMode(StopMode.Brake);
	    light.writeRegister(0, 2, 255, 0, 0);
	    light.writeRegister(2, 2, 0, 0, 255);
	    light.writeRegister(1, .25, 255, 255, 255);
	    light.writeRegister(3, .25, 255, 255, 255);
	    light.writeRegister(4, .25, 255, 0, 0);
	    gyro.initGyro();
	    gyro.calibrate();
	    
    }
	/**
	 * This autonomous (along with the chooser code above) shows how to select between different autonomous modes
	 * using the dashboard. The sendable chooser code works with the Java SmartDashboard. If you prefer the LabVIEW
	 * Dashboard, remove all of the chooser code and uncomment the getString line to get the auto name from the text box
	 * below the Gyro
	 *
	 * You can add additional auto modes by adding additional comparisons to the switch structure below with additional strings.
	 * If using the SendableChooser make sure to add them to the chooser code above as well.
	 */
    public void autonomousInit(){
    	autoSelected = (String) chooser.getSelected();
		//autoSelected = SmartDashboard.getString("Auto Selector", defaultAuto);
		//System.out.println("Auto selected: " + autoSelected);
    }
    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
    	distance = (ultra.getVoltage()/0.009765625);
    	cameraArea = table.getNumber("area", 0);
    	align = table.getNumber("align", 0);
    	switch(autoSelected){
    	case Auto9: //Scorched earth. empty hoppers; Red Alliance (2 hoppers left, 1 hopper right) 
    		if (counter == 0){ //drive forward to in front of the first hopper
				leftDrive1.set(-0.5);
				leftDrive2.set(-0.5);
				rightDrive1.set(0.5);
				rightDrive2.set(0.5);
				Timer.delay(3); //TODO: determine time
				gyro.reset();
				counter++;
			}else if(counter == 1){ //turn left towards the hopper and press it
				if(gyro.getAngle() > -90){ 
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
				}else{
					leftDrive1.set(-0.5); //TODO: determine times
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1);
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1);
    				gyro.reset();
					counter++;
				}
			}else if(counter == 2){ //turn towards middle hopper and go towards it
				if(gyro.getAngle() < 150){ //TODO: determine angle
					leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
				}else{
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(2); //TODO: determine timing
    				gyro.reset();
					counter++;
				}
			}else if(counter == 3){ //Align with hopper and press it
				if(gyro.getAngle() < 30){ //TODO: determine angle
					leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
				}else{
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1); //TODO: determine timing
    				leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(1);
    				gyro.reset();
    				counter++;
				}
			}else if(counter == 4){ //turn towards last hopper and go towards it
				if(gyro.getAngle() > -150){ //TODO: determine angle
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
				}else{
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(3); //TODO: determine timing
    				gyro.reset();
    				counter++;
				}
			}else if(counter == 5){ //align with hopper and press it
				if(gyro.getAngle() > -30){ //TODO: determine angle
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
				}else{
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1); //TODO: determine timing
    				leftDrive1.set(0.5);
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(1);
    				gyro.reset();
    				counter++;
				}
			}else if(counter == 6){ //head towards middle of field
				if(gyro.getAngle() > -90){
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
				}else{
					leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(2); //TODO: determine angle
    				counter++;
				}
			}
    		break;
    	case Auto8: //Scorched earth, empty hoppers; Blue Alliance (2 hoppers right, 1 hopper right)
    				if (counter == 0){ //drive forward to in front of the first hopper
    					leftDrive1.set(-0.5);
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
        				Timer.delay(3); //TODO: determine time
        				gyro.reset();
        				counter++;
    				}else if(counter == 1){ //turn right towards the hopper and press it
    					if(gyro.getAngle() < 90){
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(-0.5);
            				rightDrive2.set(-0.5);
    					}else{
    						leftDrive1.set(-0.5); //TODO: determine times
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(1);
            				leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(1);
            				gyro.reset();
    						counter++;
    					}
    				}else if(counter == 2){ //turn towards middle hopper and go towards it
    					if(gyro.getAngle() > -150){ //TODO: determine angle
    						leftDrive1.set(0.5);
            				leftDrive2.set(0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
    					}else{
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(2); //TODO: determine timing
            				gyro.reset();
    						counter++;
    					}
    				}else if(counter == 3){ //Align with hopper and press it
    					if(gyro.getAngle() > -30){ //TODO: determine angle
    						leftDrive1.set(0.5);
            				leftDrive2.set(0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
    					}else{
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(1); //TODO: determine timing
            				leftDrive1.set(0.5);
            				leftDrive2.set(0.5);
            				rightDrive1.set(-0.5);
            				rightDrive2.set(-0.5);
            				Timer.delay(1);
            				gyro.reset();
            				counter++;
    					}
    				}else if(counter == 4){ //turn towards last hopper and go towards it
    					if(gyro.getAngle() < 150){ //TODO: determine angle
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(-0.5);
            				rightDrive2.set(-0.5);
    					}else{
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(3); //TODO: determine timing
            				gyro.reset();
            				counter++;
    					}
    				}else if(counter == 5){ //align with hopper and press it
    					if(gyro.getAngle() < 30){ //TODO: determine angle
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(-0.5);
            				rightDrive2.set(-0.5);
    					}else{
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(1); //TODO: determine timing
            				leftDrive1.set(0.5);
            				leftDrive2.set(0.5);
            				rightDrive1.set(-0.5);
            				rightDrive2.set(-0.5);
            				Timer.delay(1);
            				gyro.reset();
            				counter++;
    					}
    				}else if(counter == 6){ //head towards middle of field
    					if(gyro.getAngle() < 90){
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(-0.5);
            				rightDrive2.set(-0.5);
    					}else{
    						leftDrive1.set(-0.5);
            				leftDrive2.set(-0.5);
            				rightDrive1.set(0.5);
            				rightDrive2.set(0.5);
            				Timer.delay(2); //TODO: determine angle
            				counter++;
    					}
    				}
    				break;
    	case Auto7://Blue Alliance, Boiler side; left peg, shoot into boiler, go to mid-field.
    		if(counter == 0){//Move forward.
				leftDrive1.set(-0.5);
				leftDrive2.set(-0.5);
				rightDrive1.set(0.5);
				rightDrive2.set(0.5);
				Timer.delay(1.8);
				gyro.reset();
				counter++;    				
			}else if(counter == 1){//Turn right towards the peg.
				leftDrive1.set(.5);
				leftDrive2.set(.5);
				rightDrive1.set(.5);
				rightDrive2.set(.5);
				Timer.delay(.43);
				counter++;
			}else if(counter == 2){
				leftDrive1.set(0);	
				leftDrive2.set(0);
    			rightDrive1.set(0);
    			rightDrive2.set(0);
    			Timer.delay(.2);
    			counter++;
			}else if(counter == 3){//Approach peg and wait there for a 2 seconds to allow the gear to be lifted.
    			leftDrive1.set(-0.5);	
				leftDrive2.set(-0.5);
    			rightDrive1.set(0.5);
    			rightDrive2.set(0.5);
    			Timer.delay(1.9);
    			counter++;
			}else if(counter == 4){//Go in reverse.
				leftDrive1.set(0.5);//TODO Determine speed and inverses
				leftDrive2.set(0.5);
				rightDrive1.set(-0.5);
				rightDrive2.set(-0.5);
				Timer.delay(1);//TODO Determine time
				counter++;
			}else if (counter == 4){
				shooter1.set(1);
				shooter2.set(-1);
				Timer.delay(0.5);
				loader.set(-1);
				Timer.delay(2);
				shooter1.set(0);
				shooter2.set(0);
				loader.set(0);
			}else{//Drive into mid-field.
				leftDrive1.set(-0.5);//TODO Determine speed and inverses
				leftDrive2.set(-0.5);
				rightDrive1.set(0.5);
				rightDrive2.set(0.5);
				Timer.delay(2);//TODO Determine time
				leftDrive1.set(0);
				leftDrive2.set(0);
				rightDrive1.set(0);
				rightDrive2.set(0);
				counter++;
			}
    	case Auto6:// Red Alliance, Boiler side; right peg, shoot into boiler, go to mid-field.
    			if(counter == 0){//Move forward.
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1.8);
    				gyro.reset();
    				counter++;    				
    			}else if(counter == 1){//Turn left towards the peg.
    				leftDrive1.set(-.5);
    				leftDrive2.set(-.5);
    				rightDrive1.set(-.5);
    				rightDrive2.set(-.5);
    				Timer.delay(.43);
    				counter++;
    			}else if(counter == 2){
    				leftDrive1.set(0);	
    				leftDrive2.set(0);
        			rightDrive1.set(0);
        			rightDrive2.set(0);
        			Timer.delay(.2);
        			counter++;
    			}else if(counter == 3){//Approach peg and wait there for a 2 seconds to allow the gear to be lifted.
        			leftDrive1.set(-0.5);	
    				leftDrive2.set(-0.5);
        			rightDrive1.set(0.5);
        			rightDrive2.set(0.5);
        			Timer.delay(1.9);
        			counter++;
    			}else if(counter == 4){//Go in reverse.
    				leftDrive1.set(0.5);//TODO Determine speed and inverses
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(1);//TODO Determine time
    				counter++;
    			}else if (counter == 4){
    				shooter1.set(1);
    				shooter2.set(-1);
    				Timer.delay(0.5);
    				loader.set(-1);
    				Timer.delay(2);
    				shooter1.set(0);
    				shooter2.set(0);
    				loader.set(0);
    			}else{//Drive into mid-field.
					leftDrive1.set(-0.5);//TODO Determine speed and inverses
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(2);//TODO Determine time
    				leftDrive1.set(0);
    				leftDrive2.set(0);
    				rightDrive1.set(0);
    				rightDrive2.set(0);
    				counter++;
				}
    			break;
    	case Auto5://Red Alliance, Loading Station side; left peg, cross baseline, go to mid-field
    			if(counter == 0){//Move forward.
    				leftDrive1.set(-0.5);//TODO Determine speed and inverses
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1);//TODO Determine time
    				gyro.reset();
    				counter++;
    			}else if(counter == 1){//Turn right towards the peg.
    				if(gyro.getAngle() < 45){//TODO Determine Angle
    					leftDrive1.set(-0.5);//TODO Determine speed and inverses
    					leftDrive2.set(-0.5);
    					rightDrive1.set(-0.5);
    					rightDrive2.set(-0.5);
    				}else{ 
    					counter++;
    				}
    			}else if(counter == 2){//Approach peg and wait there for 2 seconds to allow the gear to be lifted.
    				if(distance < 10) {//TODO Determine distance
    					leftDrive1.set(-0.5);//TODO Determine speed and inverses
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
    				}else{
    					leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				Timer.delay(2);//TODO Determine time
        				counter++;
    				}
    			}else if(counter == 3){//Go in reverse.
    				leftDrive1.set(0.5);//TODO Determine speed and inverses
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);//TODO Determine time
    				gyro.reset();
    				counter++;
    			}else if(counter == 4){//Go in reverse.
    				leftDrive1.set(0.5);//TODO Determine speed and inverses
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);//TODO Determine time
    				gyro.reset();
    				counter++;
    			}else if (counter == 5) { //Turn right towards goal
    				if (gyro.getAngle() < 60) { //TODO Determine Angle
    					leftDrive1.set(-0.5);//TODO Determine speed and inverses
        				leftDrive2.set(-0.5);
        				rightDrive1.set(-0.5);
        				rightDrive2.set(-0.5);
        				counter++;
    				}
    			}else if (counter == 6){
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(0.5);
    				leftDrive1.set(0);
    				leftDrive2.set(0);
    				rightDrive1.set(0);
    				rightDrive2.set(0);
    				shooter1.set(1);
    				shooter2.set(-1);
    				loader.set(-1);
    				Timer.delay(0.5);
    				shooter1.set(0);
    				shooter2.set(0);
    				loader.set(0);
    			}else{//Drive into mid-field.
					leftDrive1.set(-0.5);//TODO Determine speed and inverses
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(2);//TODO Determine time
    				leftDrive1.set(0);
    				leftDrive2.set(0);
    				rightDrive1.set(0);
    				rightDrive2.set(0);
    				counter++;
				}  
    			break;
    	case Auto4://Blue Alliance, Loading Station side; right peg, cross baseline, go to mid-field.
    			if(counter == 0){//Move forward.
    				leftDrive1.set(-0.5);//TODO Determine speed and inverses
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(1); //TODO determine time
    				gyro.reset();
    				counter++;
    			}else if(counter == 1){//Turn left towards the peg.
    				if(gyro.getAngle() > -45){//TODO Determine angle
    					leftDrive1.set(0.5);//TODO Determine speed and inverses
    					leftDrive2.set(0.5);
    					rightDrive1.set(0.5);
    					rightDrive2.set(0.5);
    				}else{
    					counter++;
    				}
    			}else if(counter == 2){//Approach peg and wait there for 2 seconds to allow the gear to be lifted.
    				if(distance < 10){//TODO Determine Distance
    					leftDrive1.set(-0.5);//TODO Determine speed and inverses
        				leftDrive2.set(-0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
    				}else{
    					leftDrive1.set(0);
        				leftDrive2.set(0);
        				rightDrive1.set(0);
        				rightDrive2.set(0);
        				Timer.delay(2);//TODO Determine time
        				counter++;
    				}
    			}else if(counter == 3){//Back up.
    				leftDrive1.set(0.5);//TODO Determine speed and inverses
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);//TODO Determine time
    				gyro.reset();
    				counter++;
    			}else if(counter == 4){//Go in reverse.
    				leftDrive1.set(0.5);//TODO Determine speed and inverses
    				leftDrive2.set(0.5);
    				rightDrive1.set(-0.5);
    				rightDrive2.set(-0.5);
    				Timer.delay(0.5);//TODO Determine time
    				gyro.reset();
    				counter++;
    			}else if (counter == 5) { //Turn left towards goal
    				if (gyro.getAngle() > -60) { //TODO Determine Angle
    					leftDrive1.set(0.5);//TODO Determine speed and inverses
        				leftDrive2.set(0.5);
        				rightDrive1.set(0.5);
        				rightDrive2.set(0.5);
        				counter++;
    				}
    			}else if (counter == 6){
    				leftDrive1.set(-0.5);
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    				Timer.delay(0.5);
    				leftDrive1.set(0);
    				leftDrive2.set(0);
    				rightDrive1.set(0);
    				rightDrive2.set(0);
    				shooter1.set(1);
    				shooter2.set(-1);
    				loader.set(-1);
    				Timer.delay(0.5);
    				shooter1.set(0);
    				shooter2.set(0);
    				loader.set(0);
    			}
    			break;
    	case Auto3://red Center peg then go to the mid-field to the right.
    			if(counter == 0){//Drive to the peg.
	    			if(distance > 10){// TODO Determine Distance
	    				leftDrive1.set(-0.5);//TODO Determine speed and inverses
	    				leftDrive2.set(-0.5);
	    				rightDrive1.set(0.5);
	    				rightDrive2.set(0.5);
	    			}else{
	    				counter++;
	    			}
	    		}else if(counter == 1){//Stay still to get the gear lifted.
	    			leftDrive1.set(0);
	        		leftDrive2.set(0);
	        		rightDrive1.set(0);
	        		rightDrive2.set(0);
	        		Timer.delay(2);//TODO Determine Time
	        		leftDrive1.set(0.5);//TODO Determine speed and inverses
	        		leftDrive2.set(0.5);
	        		rightDrive1.set(-0.5);
	        		rightDrive2.set(-0.5);
	        		Timer.delay(0.5);//TODO Determine Time
	        		gyro.reset();
	        		counter++;
	    		}else if(counter == 2){//Turn Right.
	        		if(gyro.getAngle() < 90){//TODO Determine angle
		        		leftDrive1.set(-0.5);//TODO Determine speed and inverses
		        		leftDrive2.set(-0.5);
		        		rightDrive1.set(-0.5);
		        		rightDrive2.set(-0.5);
	        		}else{
	        			counter++;
	        		}
	    		}else if(counter == 3){//Drive Forward to get around pilot station.
	    			leftDrive1.set(-0.5);//TODO Determine speed and inverses
	    			leftDrive2.set(-0.5);
	    			rightDrive1.set(0.5);
	    			rightDrive2.set(0.5);
	    			Timer.delay(1);//TODO Determine Time
	    			gyro.reset();
	    			counter++;
	    		}else if(counter == 4){//Turn right
	    			if(gyro.getAngle() < 90){//TODO Determine angle
	    				leftDrive1.set(-0.5);//TODO Determine speed and inverses
	    				leftDrive2.set(-0.5);
	    				rightDrive1.set(-0.5);
	    				rightDrive2.set(-0.5);
	    			}else{
	    				counter++;
	    			}
	    		}else if(counter == 5){//Drive to the boiler
	    			leftDrive1.set(-0.5);//TODO Determine speed and inverses
	    			leftDrive2.set(-0.5);
	    			rightDrive1.set(0.5);
	    			rightDrive2.set(0.5);
	    			Timer.delay(0.5);//TODO Determine Time
	    			leftDrive1.set(0);
	    			leftDrive2.set(0);
	    			rightDrive1.set(0);
	    			rightDrive2.set(0);
	    			shooter1.set(1);
	    			shooter2.set(-1);
	    			loader.set(-1);
	    			Timer.delay(1);
	    			shooter1.set(0);
	    			shooter2.set(0);
	    			loader.set(0);
	    		}
    			break;
    	case Auto2://Blue Center peg then go to the boiler to the left.
    		/*
    		if(counter == 0){//Drive to the peg.
    			if(distance > 10){// TODO Determine Distance
    				leftDrive1.set(-0.5);//TODO Determine speed and inverses
    				leftDrive2.set(-0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    			}else{
    				counter++;
    			}
    			*/
    		if (counter == 0)
    		{
    			leftDrive1.set(-0.3);
				leftDrive2.set(-0.3);
				rightDrive1.set(0.3);
				rightDrive2.set(0.3);
				Timer.delay(4);
				counter++;
    		}else if(counter == 1){//Stay still to get the gear lifted.
    			leftDrive1.set(0);
        		leftDrive2.set(0);
        		rightDrive1.set(0);
        		rightDrive2.set(0);
        		//Timer.delay(2);//TODO Determine Time
        		//leftDrive1.set(0.5);//TODO Determine speed and inverses
        		//leftDrive2.set(0.5);
        		//rightDrive1.set(-0.5);
        		//rightDrive2.set(-0.5);
        		//Timer.delay(0.5);//TODO Determine Time
        		//gyro.reset();
        		//counter++;
        	/*
    		}else if(counter == 2){//Turn Left.
        		if(gyro.getAngle() > -90){//TODO Determine angle
	        		leftDrive1.set(0.5);//TODO Determine speed and inverses
	        		leftDrive2.set(0.5);
	        		rightDrive1.set(0.5);
	        		rightDrive2.set(0.5);
        		}else{
        			counter++;
        		}
    		}else if(counter == 3){//Drive Forward
    			leftDrive1.set(-0.5);//TODO Determine speed and inverses
    			leftDrive2.set(-0.5);
    			rightDrive1.set(0.5);
    			rightDrive2.set(0.5);
    			Timer.delay(1);//TODO Determine Time
    			gyro.reset();
    			counter++;
    		}else if(counter == 4){//Turn left
    			if(gyro.getAngle() > -90){//TODO Determine angle
    				leftDrive1.set(0.5);//TODO Determine speed and inverses
    				leftDrive2.set(0.5);
    				rightDrive1.set(0.5);
    				rightDrive2.set(0.5);
    			}else{
    				counter++;
    			}
    		}else if(counter == 5){//Drive to the boiler
    			leftDrive1.set(-0.5);//TODO Determine speed and inverses
    			leftDrive2.set(-0.5);
    			rightDrive1.set(0.5);
    			rightDrive2.set(0.5);
    			Timer.delay(0.5);//TODO Determine Time
    			leftDrive1.set(0);
    			leftDrive2.set(0);
    			rightDrive1.set(0);
    			rightDrive2.set(0);
    			shooter1.set(1);
    			shooter2.set(-1);
    			loader.set(-1);
    			Timer.delay(1);
    			shooter1.set(0);
    			shooter2.set(0);
    			loader.set(0);
    		}
    		*/
    		}
			break;
    	case Auto1://Cross baseline.
    		if(idk ==0)
    		{
    			leftDrive1.set(-1);//TODO Determine speed and Inverse
	    		leftDrive2.set(-1);
	    		rightDrive1.set(1);
	    		rightDrive2.set(1);
    		}else if(idk > 0){
    			rightDrive1.set(0);
	    		leftDrive2.set(0);
	    		rightDrive2.set(0);
	    		leftDrive1.set(0);
    		}
    		Timer.delay(1.5);
    		idk++;
    			break;
    	default://Do Nothing.
    		leftDrive1.set(0);
    		leftDrive2.set(0);
    		rightDrive1.set(0);
    		rightDrive2.set(0);
            break;
    	}
    }
    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
        distance = (ultra.getVoltage()/0.009765625);//Distance in Inches from UltraSonics
        cameraArea = table.getNumber("area", 0);//Distance from PI
        align = table.getNumber("align", 0);//Alignment from PI
        yLeft = leftStick.getY();
		yRight = rightStick.getY();
		intakeForward = xbox.getBButton();
		intakeReverse = xbox.getAButton();
		climb = xbox.getXButton();
		//shoot_align = xbox.getYButton();
		funTime = xbox.getStartButton();
		shoot = xbox.getRawAxis(2);
		load = xbox.getRawAxis(3);		
		coastBreakLeft = leftStick.getRawButton(1);
		coastBreakRight = rightStick.getRawButton(1);
		left90 = leftStick.getRawButton(2);
		right90 = rightStick.getRawButton(2);
		gyroForward = rightStick.getRawButton(3);
		gyroBackward = leftStick.getRawButton(3);
		one80 = rightStick.getRawButton(4);
		gyroLock = leftStick.getRawButton(4);
		forty = rightStick.getRawButton(7);
        //Intake, A and B on XBOX; Automatically intakes balls and unjams them if they are caught for more than 2 seconds. If the button man wants he can override this by using A to intake and B to Unjam. 
        if(intakeForward && intakeReverse){
			intake.set(0);
        }else if(intakeForward){
			intake.set(1);
        }else if(intakeReverse){
			intake.set(-1);
        }else{//TODO Add sensor and test
        	/** if(IR.getVoltage() > 0.7){//TODO Test voltage to see if this is accurate
             	intake.set(1);
             	timeIntake++;
             }else if (timeIntake >= 50){//TODO Test to see if it takes two Seconds
             	intake.set(-1);
             }else{
             	intake.set(0);
             	timeIntake = 0;
             }
             */
        	intake.set(0);
        }
		//Drive Code; Two Joy-sticks for Driver
		if(Math.abs(yLeft) <= 0.2){
			leftDrive1.set(0);
			leftDrive2.set(0);
		}
		else{
			leftDrive1.set(yLeft);
			leftDrive2.set(yLeft);
		}
		if(Math.abs(yRight) <= 0.2){
			rightDrive1.set(0);
			rightDrive2.set(0);
		}
		else{
			rightDrive1.set(-yRight);
			rightDrive2.set(-yRight);
		}
		//Loads the ball from the hopper into the shooter; Left Trigger on XBOX.
		if(load <= 0.2){
			loader.set(0);//TODO Determine if this speed works for the shooter and the balls.
		}else{
			loader.set(-1);
		}
		//Aligns robot with the boiler; Y Button on XBOX; Uses Camera tracking to determine if the robot is aligned. -1 means turn right, 1 means turn left, and 0 means its aligned.
		if (shoot_align){
			if (align == -1){
				leftDrive1.set(-0.3);//TODO Determine fastest and most accurate speed for this	
				leftDrive2.set(-0.3);
				rightDrive1.set(-0.3);
				rightDrive2.set(-0.3);
			}else if (align == 1){
				leftDrive1.set(0.3);
				leftDrive2.set(0.3);
				rightDrive1.set(0.3);
				rightDrive2.set(0.3);
			}else{
				leftDrive1.set(0);
				leftDrive2.set(0);
				rightDrive1.set(0);
				rightDrive2.set(0);
			}
		}
		//Shooting; Right Trigger on XBOX; Automatic sets motor speed based on distance from boiler. If distance doesn't work it uses the value from the trigger.
		if(shoot <= 0.2){
			shooter1.set(0);
			shooter2.set(0);
		}else{
			/**
			if (cameraArea < 1000){//TODO Determine Distance and Speed ratios for shooting.
				shooter1.set(-1); 
				shooter2.set(1); 
			}
			else if(cameraArea < 1400){
				shooter1.set(-0.75);
				shooter2.set(0.75);
			}
			else if(cameraArea < 1800){
				shooter1.set(-0.5);
				shooter2.set(0.5);
			}
			else if(cameraArea < 2000){
				shooter1.set(-0.25);
				shooter2.set(0.25);
			}else{
			//	shooter1.set(-shoot);//TODO Check to see if manual shooting works
			//	shooter2.set(shoot);
			}
			*/
			shooter1.set(1);//TODO Check to see if manual shooting works
			shooter2.set(-1);
		}
		//Climber; X button on XBOX; Toggles climbing.
		if(climb == true){
			climber1.set(1);
			climber2.set(1);
		}else{
			climber1.set(0);
			climber2.set(0);
		}
		//Starts a fun time.
		if(funTime){
			xbox.setRumble(RumbleType.kLeftRumble, 1);
			xbox.setRumble(RumbleType.kRightRumble, 1);
			light.cycle(0, 3);			
		}
		else{
			xbox.setRumble(RumbleType.kLeftRumble, 0);
			xbox.setRumble(RumbleType.kRightRumble, 0);
		}
		//Joystick button Controls
		if(left90 == false && right90 == false && gyroForward == false && gyroBackward == false && one80 == false && gyroLock == false && coastBreakRight == false && coastBreakLeft == false && !forty){
			canCount = 0;
			rightDrive1.setStopMode(StopMode.Brake);
			rightDrive2.setStopMode(StopMode.Brake);
			leftDrive1.setStopMode(StopMode.Brake);
			leftDrive2.setStopMode(StopMode.Brake);
			SmartDashboard.putNumber("Brake", 1);
		}else if((left90 == true || right90 == true || gyroForward == true || gyroBackward == true || one80 == true || gyroLock == true || coastBreakRight == true || coastBreakLeft == true || forty == true) && canCount == 0){
			gyro.reset();
			canCount++;
			SmartDashboard.putNumber("Brake", 0);
		}else if((left90 == true || right90 == true || gyroForward == true || gyroBackward == true || one80 == true || gyroLock == true || coastBreakRight == true || coastBreakLeft == true || forty == true) && canCount == 1){
			//Coast-Brake system right side.
			if(coastBreakRight){
				rightDrive1.setStopMode(StopMode.Coast);
				rightDrive2.setStopMode(StopMode.Coast);
				SmartDashboard.putNumber("Coast", 1);
			}
			//Coast-Brake system left side.
			if(coastBreakLeft){
				leftDrive1.setStopMode(StopMode.Coast);
				leftDrive2.setStopMode(StopMode.Coast);
			}
			//90 degree left turn
			if(left90){
				rightDrive1.setStopMode(StopMode.Coast);
				rightDrive2.setStopMode(StopMode.Coast);
				if(gyro.getAngle() >= -46 && gyro.getAngle() <= -44){//TODO Determine Angle
					rightDrive1.set(0);
					rightDrive2.set(0);
				}else{
					rightDrive1.set(1);//TODO Determine speed and inverses
					rightDrive2.set(1);
				}
			}
			//90 degree right turn
			if(right90){
				leftDrive1.setStopMode(StopMode.Coast);
				leftDrive2.setStopMode(StopMode.Coast);
				if(gyro.getAngle() >= 44 && gyro.getAngle() <= 45){//TODO Determine Angle
					leftDrive1.set(0);
					leftDrive2.set(0);
				}else{
					leftDrive1.set(-1);//TODO Determine speed and inverses
					leftDrive2.set(-1);
				}
			}
			//Gyro forward straight drive.
			if(gyroForward){//TODO Determine Button
				if(gyro.getAngle() > 5){//TODO Determine angle
					leftDrive1.set(-.8);//TODO Determine speeds and inverses
					leftDrive2.set(-.8);
					rightDrive1.set(1);
					rightDrive2.set(1);
				}else if(gyro.getAngle() < -5){//TODO Determine angle
					leftDrive1.set(-1);
					leftDrive2.set(-1);
					rightDrive1.set(.8);
					rightDrive2.set(.8);
				}else{
					leftDrive1.set(-1);
					leftDrive2.set(-1);
					rightDrive1.set(1);
					rightDrive2.set(1);
				}
			}
			if(forty)
			{
				SmartDashboard.putString("Buton", "yes");
				leftDrive1.set(-1);
				leftDrive2.set(-1);
				rightDrive1.set(-1);
				rightDrive2.set(-1);
			}
			//Gyro backward straight drive.
			if(gyroBackward){//TODO Determine Button
				if(gyro.getAngle() > 5){//TODO Determine angle
					leftDrive1.set(.8);//TODO Determine speeds and inverses
					leftDrive2.set(.8);
					rightDrive1.set(-1);
					rightDrive2.set(-1);
				}else if(gyro.getAngle() < -5){//TODO Determine angle
					leftDrive1.set(1);
					leftDrive2.set(1);
					rightDrive1.set(-.8);
					rightDrive2.set(-.8);
				}else{
					leftDrive1.set(1);
					leftDrive2.set(1);
					rightDrive1.set(-1);
					rightDrive2.set(-1);
				}
			}
			//180 degree flip
			if(one80){//TODO Determine Button
				if(gyro.getAngle() <= 185 && gyro.getAngle() >= 175){//TODO Determine Angle
					leftDrive1.set(0);
					leftDrive2.set(0);
				}else{
					leftDrive1.set(-1);
					leftDrive2.set(-1);
				}
			}
			//Gyro Lock system aka Can't Touch this
			if(gyroLock){//TODO Determine Button
				if(gyro.getAngle() < 0){
					leftDrive1.set(-1);//TODO Determine speed and inverses
					leftDrive2.set(-1);
				}else if(gyro.getAngle() > 0){
					rightDrive1.set(1);
					rightDrive2.set(1);
				}else{
					leftDrive1.set(0);
					leftDrive2.set(0);
					rightDrive1.set(0);
					rightDrive2.set(0);
				}
			}
		}
        SmartDashboard.putNumber("Distance (in):", distance);
        SmartDashboard.putNumber("Angle: ", gyro.getAngle());
        SmartDashboard.putNumber("area", cameraArea);
        SmartDashboard.putNumber("align", align);
        SmartDashboard.putNumber("Intake Jamed Time", timeIntake);
        SmartDashboard.putNumber("IR", IR.getVoltage());   
        table.putNumber("Distance", distance);
        table.putNumber("Angle", gyro.getAngle());
        table.putNumber("Intake Jamed Time", timeIntake);
        table.putNumber("IR", IR.getVoltage());
    }
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic(){
    
    }  
}